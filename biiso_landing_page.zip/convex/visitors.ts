import { mutation, query } from "./_generated/server";

export const getCount = query({
  args: {},
  handler: async (ctx) => {
    const record = await ctx.db.query("visitors").first();
    return record?.count ?? 0;
  },
});

export const increment = mutation({
  args: {},
  handler: async (ctx) => {
    const record = await ctx.db.query("visitors").first();
    if (record) {
      await ctx.db.patch(record._id, { count: record.count + 1 });
    } else {
      await ctx.db.insert("visitors", { count: 1 });
    }
    return null;
  },
});
