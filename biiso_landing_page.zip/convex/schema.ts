import { defineSchema, defineTable } from "convex/server";
import { authTables } from "@convex-dev/auth/server";
import { v } from "convex/values";

const applicationTables = {
  visitors: defineTable({
    count: v.number(),
  }),
};

export default defineSchema({
  ...authTables,
  ...applicationTables,
});
