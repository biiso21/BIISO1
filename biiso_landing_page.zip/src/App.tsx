import { useEffect, useRef } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "../convex/_generated/api";

const LINKS = [
  {
    name: "Kick",
    url: "https://kick.com/biiso2",
    color: "#53FC18",
    textColor: "#000",
    icon: (
      <svg viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5 sm:w-6 sm:h-6">
        <path d="M2 2h4v6l4-6h4l-5 7 5 7h-4l-4-6v6H2V2zm14 0h4v20h-4V2z" />
      </svg>
    ),
  },
  {
    name: "Instagram",
    url: "https://www.instagram.com/byn_0721?igsh=MWMxOW5weTRwanZ5cA==",
    color: "#E1306C",
    textColor: "#fff",
    icon: (
      <svg viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5 sm:w-6 sm:h-6">
        <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z" />
      </svg>
    ),
  },
  {
    name: "Discord",
    url: "https://discord.gg/4HStAhNQDw",
    color: "#5865F2",
    textColor: "#fff",
    icon: (
      <svg viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5 sm:w-6 sm:h-6">
        <path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0 12.64 12.64 0 0 0-.617-1.25.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057c.002.022.015.043.033.055a19.9 19.9 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028 14.09 14.09 0 0 0 1.226-1.994.076.076 0 0 0-.041-.106 13.107 13.107 0 0 1-1.872-.892.077.077 0 0 1-.008-.128 10.2 10.2 0 0 0 .372-.292.074.074 0 0 1 .077-.01c3.928 1.793 8.18 1.793 12.062 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127 12.299 12.299 0 0 1-1.873.892.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028 19.839 19.839 0 0 0 6.002-3.03.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.03zM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.956-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.956 2.418-2.157 2.418zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.955-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.946 2.418-2.157 2.418z" />
      </svg>
    ),
  },
  {
    name: "YouTube",
    url: "https://youtube.com/@biiso_01?si=7Q_Y6m3RD1YqOtan",
    color: "#FF0000",
    textColor: "#fff",
    icon: (
      <svg viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5 sm:w-6 sm:h-6">
        <path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z" />
      </svg>
    ),
  },
];

function StarCanvas() {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let animationId: number;

    const resize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };
    resize();
    window.addEventListener("resize", resize);

    const stars = Array.from({ length: 160 }, () => ({
      x: Math.random() * window.innerWidth,
      y: Math.random() * window.innerHeight,
      r: Math.random() * 2.2 + 0.3,
      alpha: Math.random(),
      speed: Math.random() * 0.012 + 0.004,
      dir: Math.random() > 0.5 ? 1 : -1,
    }));

    const draw = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      for (const s of stars) {
        s.alpha += s.speed * s.dir;
        if (s.alpha >= 1) { s.alpha = 1; s.dir = -1; }
        if (s.alpha <= 0) { s.alpha = 0; s.dir = 1; }
        ctx.beginPath();
        ctx.arc(s.x, s.y, s.r, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(255,255,255,${s.alpha})`;
        ctx.shadowBlur = 8;
        ctx.shadowColor = "rgba(200,180,255,0.9)";
        ctx.fill();
      }
      animationId = requestAnimationFrame(draw);
    };
    draw();

    return () => {
      cancelAnimationFrame(animationId);
      window.removeEventListener("resize", resize);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className="fixed inset-0 pointer-events-none"
      style={{ zIndex: 0 }}
    />
  );
}

export default function App() {
  const visitorCount = useQuery(api.visitors.getCount);
  const increment = useMutation(api.visitors.increment);

  useEffect(() => {
    const key = "biiso_visited";
    if (!sessionStorage.getItem(key)) {
      sessionStorage.setItem(key, "1");
      increment();
    }
  }, [increment]);

  return (
    <div
      className="min-h-screen w-full flex flex-col items-center justify-center relative overflow-x-hidden"
      style={{
        background: "linear-gradient(135deg, #1a0533 0%, #3b0764 40%, #5b21b6 70%, #2e1065 100%)",
        minHeight: "100dvh",
      }}
    >
      <StarCanvas />

      {/* Main Content */}
      <div
        className="relative z-10 flex flex-col items-center w-full py-10 sm:py-16"
        style={{ padding: "clamp(24px, 6vw, 64px) clamp(16px, 5vw, 32px)" }}
      >
        <div className="w-full" style={{ maxWidth: "min(520px, 100%)" }}>

          {/* Name */}
          <div className="text-center select-none mb-8 sm:mb-10">
            <h1
              className="font-black"
              style={{
                fontSize: "clamp(3.2rem, 22vw, 8rem)",
                lineHeight: 1.1,
                background: "linear-gradient(180deg, #ffffff 0%, #d8b4fe 50%, #a855f7 100%)",
                WebkitBackgroundClip: "text",
                WebkitTextFillColor: "transparent",
                backgroundClip: "text",
                filter: "drop-shadow(0 0 32px rgba(168,85,247,0.8))",
                letterSpacing: "0.15em",
              }}
            >
              Biiso
            </h1>
            <p
              className="text-purple-200 font-medium tracking-widest mt-2"
              style={{
                fontSize: "clamp(0.8rem, 3.5vw, 1.05rem)",
                textShadow: "0 0 12px rgba(168,85,247,0.7)",
              }}
            >
              ✦ تابعني على منصاتي ✦
            </p>
          </div>

          {/* Buttons */}
          <div className="flex flex-col w-full" style={{ gap: "clamp(10px, 2.5vw, 16px)" }}>
            {LINKS.map((link) => (
              <a
                key={link.name}
                href={link.url}
                target="_blank"
                rel="noopener noreferrer"
                className="group flex items-center font-bold rounded-2xl transition-all duration-300 active:scale-95"
                style={{
                  gap: "clamp(10px, 3vw, 16px)",
                  padding: "clamp(11px, 3vw, 16px) clamp(14px, 4vw, 24px)",
                  fontSize: "clamp(0.9rem, 3.8vw, 1.1rem)",
                  background: `linear-gradient(135deg, ${link.color}22 0%, ${link.color}44 100%)`,
                  border: `2px solid ${link.color}88`,
                  color: "#fff",
                  boxShadow: `0 4px 24px ${link.color}33`,
                  WebkitTapHighlightColor: "transparent",
                  touchAction: "manipulation",
                }}
                onMouseEnter={(e) => {
                  const el = e.currentTarget as HTMLAnchorElement;
                  el.style.boxShadow = `0 8px 40px ${link.color}77`;
                  el.style.borderColor = link.color;
                  el.style.background = `linear-gradient(135deg, ${link.color}44 0%, ${link.color}66 100%)`;
                  el.style.transform = "scale(1.03)";
                }}
                onMouseLeave={(e) => {
                  const el = e.currentTarget as HTMLAnchorElement;
                  el.style.boxShadow = `0 4px 24px ${link.color}33`;
                  el.style.borderColor = `${link.color}88`;
                  el.style.background = `linear-gradient(135deg, ${link.color}22 0%, ${link.color}44 100%)`;
                  el.style.transform = "scale(1)";
                }}
              >
                <span
                  className="flex items-center justify-center rounded-xl flex-shrink-0"
                  style={{
                    width: "clamp(34px, 9vw, 44px)",
                    height: "clamp(34px, 9vw, 44px)",
                    minWidth: "34px",
                    background: link.color,
                    color: link.textColor,
                  }}
                >
                  {link.icon}
                </span>
                <span className="flex-1">{link.name}</span>
                <svg
                  className="flex-shrink-0 opacity-50 group-hover:opacity-100 transition-all"
                  style={{ width: "clamp(14px, 4vw, 20px)", height: "clamp(14px, 4vw, 20px)" }}
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                </svg>
              </a>
            ))}
          </div>

        </div>
      </div>

      {/* Visitor Counter */}
      <div
        className="fixed z-20 flex items-center gap-2 rounded-full font-semibold"
        style={{
          bottom: "clamp(10px, 3vw, 20px)",
          right: "clamp(10px, 3vw, 20px)",
          padding: "clamp(5px, 1.5vw, 8px) clamp(10px, 3vw, 16px)",
          fontSize: "clamp(0.65rem, 2.8vw, 0.875rem)",
          background: "rgba(88,28,135,0.85)",
          border: "1px solid rgba(168,85,247,0.5)",
          color: "#e9d5ff",
          backdropFilter: "blur(8px)",
          boxShadow: "0 4px 20px rgba(88,28,135,0.5)",
          whiteSpace: "nowrap",
        }}
      >
        <span>👁️</span>
        <span>
          {visitorCount === undefined ? "..." : visitorCount.toLocaleString()} زيارة
        </span>
      </div>
    </div>
  );
}
